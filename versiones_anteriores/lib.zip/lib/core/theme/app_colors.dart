import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFF0F131C);
  static const surface = Color(0xFF161B25);
  static const surfaceHigh = Color(0xFF202635);
  static const surfaceHighest = Color(0xFF2B3244);

  static const primary = Color(0xFFF2CA50);
  static const primaryDark = Color(0xFFD4AF37);

  static const xColor = Color(0xFF43E2D2);
  static const oColor = Color(0xFFFFBEBB);
  static const triangleColor = Color(0xFFB388FF);
  static const squareColor = Color(0xFFF4D35E);

  static const textPrimary = Color(0xFFDFE2EF);
  static const textSecondary = Color(0xFFA8B0C3);
  static const danger = Color(0xFFF07178);
}
