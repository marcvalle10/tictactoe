class Validators {
  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Ingresa tu correo';
    }
    if (!value.contains('@')) {
      return 'Correo inválido';
    }
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) {
      return 'Ingresa tu contraseña';
    }
    if (value.length < 6) {
      return 'Mínimo 6 caracteres';
    }
    return null;
  }

  static String? requiredField(String? value, String field) {
    if (value == null || value.trim().isEmpty) {
      return 'Ingresa $field';
    }
    return null;
  }
}
