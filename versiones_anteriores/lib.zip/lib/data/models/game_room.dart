import 'game_mode.dart';
import 'room_player.dart';

class GameRoom {
  final String roomCode;
  final String hostId;
  final GameMode mode;
  final int boardSize;
  final int winLength;
  final String status;
  final int currentTurnIndex;
  final String currentSymbol;
  final List<List<String>> board;
  final List<RoomPlayer> players;

  const GameRoom({
    required this.roomCode,
    required this.hostId,
    required this.mode,
    required this.boardSize,
    required this.winLength,
    required this.status,
    required this.currentTurnIndex,
    required this.currentSymbol,
    required this.board,
    required this.players,
  });

  factory GameRoom.fromMap(Map<dynamic, dynamic> map) {
    final playersMap = (map['players'] as Map<dynamic, dynamic>? ?? {});
    final boardRaw = (map['board'] as List<dynamic>? ?? []);

    return GameRoom(
      roomCode: map['roomCode'] ?? '',
      hostId: map['hostId'] ?? '',
      mode: GameModeX.fromKey(map['mode'] ?? 'classic'),
      boardSize: map['boardSize'] ?? 3,
      winLength: map['winLength'] ?? 3,
      status: map['status'] ?? 'waiting',
      currentTurnIndex: map['currentTurnIndex'] ?? 0,
      currentSymbol: map['currentSymbol'] ?? 'X',
      board: boardRaw
          .map<List<String>>(
            (row) => (row as List<dynamic>).map((cell) => '$cell').toList(),
          )
          .toList(),
      players: playersMap.values
          .map((e) => RoomPlayer.fromMap(e as Map<dynamic, dynamic>))
          .toList(),
    );
  }
}
