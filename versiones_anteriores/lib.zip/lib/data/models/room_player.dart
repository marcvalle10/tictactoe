class RoomPlayer {
  final String uid;
  final String name;
  final String symbol;
  final String colorHex;
  final bool isHost;
  final bool isOnline;
  final int score;

  const RoomPlayer({
    required this.uid,
    required this.name,
    required this.symbol,
    required this.colorHex,
    required this.isHost,
    required this.isOnline,
    required this.score,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'symbol': symbol,
      'color': colorHex,
      'isHost': isHost,
      'isOnline': isOnline,
      'score': score,
    };
  }

  factory RoomPlayer.fromMap(Map<dynamic, dynamic> map) {
    return RoomPlayer(
      uid: map['uid'] ?? '',
      name: map['name'] ?? '',
      symbol: map['symbol'] ?? '',
      colorHex: map['color'] ?? '#FFFFFF',
      isHost: map['isHost'] ?? false,
      isOnline: map['isOnline'] ?? false,
      score: map['score'] ?? 0,
    );
  }
}
