enum GameMode {
  classic,
  multiplayer4,
  rotatingSymbols,
}

extension GameModeX on GameMode {
  String get key => switch (this) {
        GameMode.classic => 'classic',
        GameMode.multiplayer4 => 'multiplayer4',
        GameMode.rotatingSymbols => 'rotatingSymbols',
      };

  String get title => switch (this) {
        GameMode.classic => 'Modo Clásico',
        GameMode.multiplayer4 => 'Multijugador 4',
        GameMode.rotatingSymbols => 'Rotación de Símbolos',
      };

  int get boardSize => switch (this) {
        GameMode.classic => 3,
        GameMode.multiplayer4 => 6,
        GameMode.rotatingSymbols => 6,
      };

  int get maxPlayers => switch (this) {
        GameMode.classic => 2,
        GameMode.multiplayer4 => 4,
        GameMode.rotatingSymbols => 4,
      };

  int get winLength => switch (this) {
        GameMode.classic => 3,
        GameMode.multiplayer4 => 4,
        GameMode.rotatingSymbols => 5,
      };

  static GameMode fromKey(String key) {
    return GameMode.values.firstWhere(
      (e) => e.key == key,
      orElse: () => GameMode.classic,
    );
  }
}
