import 'dart:math';

import 'package:firebase_database/firebase_database.dart';

import '../models/game_mode.dart';
import '../models/game_room.dart';
import '../models/room_player.dart';

class RoomRepository {
  final FirebaseDatabase _db = FirebaseDatabase.instance;

  DatabaseReference get _roomsRef => _db.ref('rooms');

  String generateRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final random = Random();
    return List.generate(
      6,
      (_) => chars[random.nextInt(chars.length)],
    ).join();
  }

  List<List<String>> _createEmptyBoard(int size) {
    return List.generate(size, (_) => List.generate(size, (_) => ''));
  }

  List<Map<String, String>> _symbolsForMode(GameMode mode) {
    switch (mode) {
      case GameMode.classic:
        return const [
          {'symbol': 'X', 'color': '#43E2D2'},
          {'symbol': 'O', 'color': '#FFBEBB'},
        ];
      case GameMode.multiplayer4:
      case GameMode.rotatingSymbols:
        return const [
          {'symbol': 'X', 'color': '#43E2D2'},
          {'symbol': 'O', 'color': '#FFBEBB'},
          {'symbol': '△', 'color': '#B388FF'},
          {'symbol': '□', 'color': '#F4D35E'},
        ];
    }
  }

  Future<String> createRoom({
    required String uid,
    required String playerName,
    required GameMode mode,
  }) async {
    String code = generateRoomCode();
    final roomRef = _roomsRef.child(code);

    final existing = await roomRef.get();
    if (existing.exists) {
      code = generateRoomCode();
    }

    final symbols = _symbolsForMode(mode);
    final player = RoomPlayer(
      uid: uid,
      name: playerName,
      symbol: symbols.first['symbol']!,
      colorHex: symbols.first['color']!,
      isHost: true,
      isOnline: true,
      score: 0,
    );

    final now = DateTime.now().millisecondsSinceEpoch;

    await _roomsRef.child(code).set({
      'roomCode': code,
      'hostId': uid,
      'mode': mode.key,
      'boardSize': mode.boardSize,
      'winLength': mode.winLength,
      'status': 'waiting',
      'currentTurnIndex': 0,
      'currentSymbol': symbols.first['symbol'],
      'createdAt': now,
      'updatedAt': now,
      'players': {
        uid: player.toMap(),
      },
      'board': _createEmptyBoard(mode.boardSize),
    });

    return code;
  }

  Future<void> joinRoom({
    required String roomCode,
    required String uid,
    required String playerName,
  }) async {
    final snapshot = await _roomsRef.child(roomCode).get();

    if (!snapshot.exists) {
      throw Exception('La sala no existe');
    }

    final room = GameRoom.fromMap(snapshot.value as Map<dynamic, dynamic>);

    if (room.players.any((p) => p.uid == uid)) {
      await _roomsRef.child(roomCode).child('players').child(uid).update({
        'isOnline': true,
      });
      return;
    }

    if (room.players.length >= room.mode.maxPlayers) {
      throw Exception('La sala ya está llena');
    }

    final symbols = _symbolsForMode(room.mode);
    final assigned = symbols[room.players.length];

    final player = RoomPlayer(
      uid: uid,
      name: playerName,
      symbol: assigned['symbol']!,
      colorHex: assigned['color']!,
      isHost: false,
      isOnline: true,
      score: 0,
    );

    await _roomsRef
        .child(roomCode)
        .child('players')
        .child(uid)
        .set(player.toMap());

    final shouldStart = room.players.length + 1 >= 2;

    await _roomsRef.child(roomCode).update({
      'status': shouldStart ? 'ready' : 'waiting',
      'updatedAt': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Stream<GameRoom?> watchRoom(String roomCode) {
    return _roomsRef.child(roomCode).onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return null;
      return GameRoom.fromMap(value as Map<dynamic, dynamic>);
    });
  }

  Future<void> leaveRoom({
    required String roomCode,
    required String uid,
  }) async {
    final roomRef = _roomsRef.child(roomCode);
    final snapshot = await roomRef.get();

    if (!snapshot.exists) return;

    await roomRef.child('players').child(uid).remove();
  }
}
