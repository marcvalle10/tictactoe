import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'data/repositories/auth_repository.dart';
import 'data/repositories/ranking_repository.dart';
import 'data/repositories/room_repository.dart';
import 'features/auth/auth_controller.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    MultiProvider(
      providers: [
        Provider(create: (_) => AuthRepository()),
        Provider(create: (_) => RoomRepository()),
        Provider(create: (_) => RankingRepository()),
        ChangeNotifierProvider(
          create: (context) => AuthController(
            context.read<AuthRepository>(),
          ),
        ),
      ],
      child: const TicTacticApp(),
    ),
  );
}
