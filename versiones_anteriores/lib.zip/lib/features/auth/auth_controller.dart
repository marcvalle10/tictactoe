import 'package:flutter/material.dart';

import '../../data/repositories/auth_repository.dart';

class AuthController extends ChangeNotifier {
  AuthController(this._authRepository);

  final AuthRepository _authRepository;

  bool _isLoading = false;
  String? _error;

  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> login({
    required String email,
    required String password,
  }) async {
    _setLoading(true);
    _error = null;

    try {
      await _authRepository.signIn(email: email, password: password);
    } catch (e) {
      _error = 'No fue posible iniciar sesión';
    } finally {
      _setLoading(false);
    }
  }

  Future<void> register({
    required String name,
    required String email,
    required String password,
  }) async {
    _setLoading(true);
    _error = null;

    try {
      await _authRepository.register(
        name: name,
        email: email,
        password: password,
      );
    } catch (e) {
      _error = 'No fue posible crear la cuenta';
    } finally {
      _setLoading(false);
    }
  }

  Future<void> signOut() => _authRepository.signOut();

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
