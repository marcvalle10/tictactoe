import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/validators.dart';
import '../../shared/widgets/gold_button.dart';
import '../../shared/widgets/obsidian_card.dart';
import '../../shared/widgets/text_input_field.dart';
import 'auth_controller.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();

    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: ObsidianCard(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const Text(
                        'Crear cuenta',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 24),
                      TextInputField(
                        controller: _nameCtrl,
                        hint: 'Nombre',
                        validator: (v) =>
                            Validators.requiredField(v, 'tu nombre'),
                      ),
                      const SizedBox(height: 14),
                      TextInputField(
                        controller: _emailCtrl,
                        hint: 'Correo',
                        validator: Validators.email,
                      ),
                      const SizedBox(height: 14),
                      TextInputField(
                        controller: _passCtrl,
                        hint: 'Contraseña',
                        obscureText: true,
                        validator: Validators.password,
                      ),
                      const SizedBox(height: 18),
                      GoldButton(
                        label: auth.isLoading ? 'Creando...' : 'Crear cuenta',
                        onPressed: auth.isLoading
                            ? null
                            : () async {
                                if (!_formKey.currentState!.validate()) return;
                                await auth.register(
                                  name: _nameCtrl.text,
                                  email: _emailCtrl.text,
                                  password: _passCtrl.text,
                                );
                                if (context.mounted) {
                                  Navigator.of(context).pop();
                                }
                              },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
