import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/repositories/room_repository.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({
    super.key,
    required this.roomCode,
  });

  final String roomCode;

  @override
  Widget build(BuildContext context) {
    final roomStream = context.read<RoomRepository>().watchRoom(roomCode);

    return Scaffold(
      appBar: AppBar(title: const Text('Tablero')),
      body: StreamBuilder(
        stream: roomStream,
        builder: (context, snapshot) {
          final room = snapshot.data;

          if (room == null) {
            return const Center(child: CircularProgressIndicator());
          }

          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text(
                  room.mode.title,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'Turno actual: ${room.currentSymbol}',
                  style: const TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: GridView.builder(
                    itemCount: room.boardSize * room.boardSize,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: room.boardSize,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemBuilder: (context, index) {
                      final row = index ~/ room.boardSize;
                      final col = index % room.boardSize;
                      final value = room.board[row][col];

                      return Container(
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surface,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Center(
                          child: Text(
                            value,
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
