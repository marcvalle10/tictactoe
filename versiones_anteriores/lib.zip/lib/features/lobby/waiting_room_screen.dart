import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/game_mode.dart';
import '../../data/models/game_room.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/repositories/room_repository.dart';
import '../../shared/widgets/gold_button.dart';
import '../../shared/widgets/obsidian_card.dart';
import '../game/game_screen.dart';

class WaitingRoomScreen extends StatefulWidget {
  const WaitingRoomScreen({
    super.key,
    required this.mode,
  });

  final GameMode mode;

  @override
  State<WaitingRoomScreen> createState() => _WaitingRoomScreenState();
}

class _WaitingRoomScreenState extends State<WaitingRoomScreen> {
  final _joinCtrl = TextEditingController();

  String? roomCode;
  StreamSubscription<GameRoom?>? _roomSub;
  GameRoom? room;
  bool busy = false;
  String? error;

  @override
  void dispose() {
    _joinCtrl.dispose();
    _roomSub?.cancel();
    super.dispose();
  }

  Future<void> _createRoom() async {
    final authRepo = context.read<AuthRepository>();
    final roomRepo = context.read<RoomRepository>();
    final user = authRepo.currentUser;

    if (user == null) return;

    setState(() {
      busy = true;
      error = null;
    });

    try {
      final code = await roomRepo.createRoom(
        uid: user.uid,
        playerName: user.displayName ?? 'Jugador',
        mode: widget.mode,
      );

      _listenRoom(code);
      setState(() => roomCode = code);
    } catch (_) {
      setState(() => error = 'No se pudo crear la sala');
    } finally {
      if (mounted) {
        setState(() => busy = false);
      }
    }
  }

  Future<void> _joinRoom() async {
    final authRepo = context.read<AuthRepository>();
    final roomRepo = context.read<RoomRepository>();
    final user = authRepo.currentUser;

    if (user == null) return;

    final code = _joinCtrl.text.trim().toUpperCase();
    if (code.isEmpty) return;

    setState(() {
      busy = true;
      error = null;
    });

    try {
      await roomRepo.joinRoom(
        roomCode: code,
        uid: user.uid,
        playerName: user.displayName ?? 'Jugador',
      );

      _listenRoom(code);
      setState(() => roomCode = code);
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) {
        setState(() => busy = false);
      }
    }
  }

  void _listenRoom(String code) {
    _roomSub?.cancel();
    _roomSub = context.read<RoomRepository>().watchRoom(code).listen((event) {
      if (!mounted) return;

      setState(() => room = event);

      if (event != null &&
          event.players.length >= 2 &&
          event.status == 'ready') {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => GameScreen(roomCode: code),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final selectedMode = widget.mode;

    return Scaffold(
      appBar: AppBar(title: const Text('Sala de espera')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            ObsidianCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Modo seleccionado',
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    selectedMode.title,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ObsidianCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Tu código',
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    roomCode ?? '------',
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 4,
                    ),
                  ),
                  const SizedBox(height: 16),
                  GoldButton(
                    label: busy ? 'Creando...' : 'Crear sala',
                    onPressed: busy ? null : _createRoom,
                    icon: Icons.add_circle_outline,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ObsidianCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Unirse a sala'),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _joinCtrl,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(
                      hintText: 'Ingresa el código',
                    ),
                  ),
                  const SizedBox(height: 16),
                  GoldButton(
                    label: busy ? 'Uniéndote...' : 'Unirse',
                    onPressed: busy ? null : _joinRoom,
                  ),
                ],
              ),
            ),
            if (room != null) ...[
              const SizedBox(height: 16),
              ObsidianCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Jugadores en sala',
                      style: TextStyle(fontSize: 13),
                    ),
                    const SizedBox(height: 10),
                    ...room!.players.map(
                      (p) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text('${p.symbol}  ${p.name}'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            if (error != null) ...[
              const SizedBox(height: 16),
              Text(
                error!,
                style: const TextStyle(color: Colors.redAccent),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
